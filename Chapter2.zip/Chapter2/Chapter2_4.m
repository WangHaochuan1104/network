%ͼ8

set(0,'defaultfigurecolor','w');%������ͼ��ɫ����
L = 30;%��������
N = 80;%�����нڵ�����
v = 2;%ƽ���ƶ��ٶ�
r = 10;%ͨ�Ű뾶
t_set = 10;%����ʱ��

position = zeros(N,2);
X = position(:,1);
Y = position(:,2);

for i = 1:N
    X(i) = L.*rand;
    Y(i) = L.*rand;
end

%�ٶ������ֽ�
vx = zeros(N,1);
vy = zeros(N,1);
vy_flag = 1;%y���ٶȷ���


% figure(1);
% scatter(X,Y,'filled','r');
% title('t=10ʱ������Ľڵ�λ�ú�����');
% for i= 1:N
%     for j = 1:N
%         if (i~=j)&&(r >= sqrt((X(i)-X(j)).^2 + (Y(i)-Y(j)).^2))
%             line([X(i) X(j)],[Y(i) Y(j)]);
%         end
%     end
% end
% box on;

mento_carlo = 1000;
p_k_average = zeros(mento_carlo,30);
R = zeros(6,30);
for r = 2:7
    for k = 1:mento_carlo

        for t=1:t_set
            %�ڵ��ƶ�
            for i= 1:N
                vx(i) = -v + 2.*v.*rand;
                vy(i) = -v + 2.*v.*rand;
                if vy(i)>=0
                    vy_flag = 1;
                else
                    vy_flag = -1;
                end
                vy(i) = vy_flag.*sqrt(v.^2-vx(i).^2);
                %���ƶ����ᳬ�����淶Χ����ڵ��ƶ�
                if((X(i)+vx(i))<=L)&&((X(i)+vx(i))>=0)
                    X(i)= X(i)+vx(i);
                end
                if((Y(i)+vy(i))<=L)&&((Y(i)+vy(i))>=0)
                    Y(i)= Y(i)+vy(i);
                end
            end
        end
 
        %���������ڽӾ���
        M = zeros(N);
        D = zeros(N);
        for i = 1:N
            for j=1:N
                if (i~=j)
                    D(i,j)=sqrt((X(i)-X(j)).^2 + (Y(i)-Y(j)).^2);
                    if(r>=D(i,j))
                        M(i,j)=D(i,j);
                    else
                        M(i,j)=inf;
                    end
                end
            end
        end
%
        k_num = zeros(1,N);
        p_k = zeros(1,30);
        for i=1:N
            for j=1:N
                if (i~=j)&&(M(i,j)~=inf)
                    k_num(i)=k_num(i)+1;
                end
            end
        end
        
        %numel(unique(k_num));%unique��k_num�в�ͬ��Ԫ�أ�numel��Ԫ�ظ���
        
        for i = 1:30
            temp2 = 0;
            for j = 1:N
                if k_num(j)==i
                   temp2 = temp2+1;
                end
            end
            p_k(i)=temp2./N;
        end
%       
        p_k_average(k,:) = p_k;
        
    end
        R(r,:)=mean(p_k_average);
end

figure(1);
hold on;
plot(R(2,:),'-o');
plot(R(3,:),'-*');
plot(R(4,:),'-^');
plot(R(5,:),'-square');
plot(R(6,:),'-diamond');
plot(R(7,:),'-pentagram');
legend('r=2','r=3','r=4','r=5','r=6','r=7');
box on;
grid on;