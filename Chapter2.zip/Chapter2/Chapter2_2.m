set(0,'defaultfigurecolor','w');%������ͼ��ɫ����
L = 30;%��������
N = 80;%�����нڵ�����
v = 2;%ƽ���ƶ��ٶ�
r = 10;%ͨ�Ű뾶
t_set = 10;%����ʱ��

position = zeros(N,2);
X = position(:,1);
Y = position(:,2);

for i = 1:N
    X(i) = L.*rand;
    Y(i) = L.*rand;
end

%�ٶ������ֽ�
vx = zeros(N,1);
vy = zeros(N,1);
vy_flag = 1;%y���ٶȷ���


% figure(1);
% scatter(X,Y,'filled','r');
% title('t=10ʱ������Ľڵ�λ�ú�����');
% for i= 1:N
%     for j = 1:N
%         if (i~=j)&&(r >= sqrt((X(i)-X(j)).^2 + (Y(i)-Y(j)).^2))
%             line([X(i) X(j)],[Y(i) Y(j)]);
%         end
%     end
% end
% box on;

mento_carlo = 10;
Lmin_average = zeros(mento_carlo,1);
R = zeros(10,1);
for r = 1:10
    for k = 1:mento_carlo
        
        for t=1:t_set
            %�ڵ��ƶ�
            for i= 1:N
                vx(i) = -v + 2.*v.*rand;
                vy(i) = -v + 2.*v.*rand;
                if vy(i)>=0
                    vy_flag = 1;
                else
                    vy_flag = -1;
                end
                vy(i) = vy_flag.*sqrt(v.^2-vx(i).^2);
                %���ƶ����ᳬ�����淶Χ����ڵ��ƶ�
                if((X(i)+vx(i))<=L)&&((X(i)+vx(i))>=0)
                    X(i)= X(i)+vx(i);
                end
                if((Y(i)+vy(i))<=L)&&((Y(i)+vy(i))>=0)
                    Y(i)= Y(i)+vy(i);
                end
            end
        end
         
        %���������ڽӾ���
        M = zeros(N);
        D = zeros(N);
        for i = 1:N
            for j=1:N
                if (i~=j)
                    D(i,j)=sqrt((X(i)-X(j)).^2 + (Y(i)-Y(j)).^2);
                    if(r>=D(i,j))
                        M(i,j)=D(i,j);
                    else
                        M(i,j)=inf;
                    end
                end
            end
        end

        %�����·��
        Dmin = zeros(N);
        Dmin_temp = zeros(N);
        temp1 = 0;
        Lmin_sum = zeros(N,1);
        Lmin = zeros(N,1);
        for i = 1:N
            for j = 1:N
                Dmin(i,j) = mydijkstra(M,i,j);
            end

            for j = 1:N
                if Dmin(i,j)==inf
                    Dmin_temp(i,j) = 0;
                else
                    Dmin_temp(i,j) = Dmin(i,j);
                end 
            end

            temp1 = 0;
            for j = 1:N
                if Dmin_temp(i,j)==0
                    temp1 = temp1+1;
                else
                    Lmin_sum(i)= Lmin_sum(i)+Dmin_temp(i,j);
                end
            end

            if temp1<N
                Lmin(i) = Lmin_sum(i)/(N-temp1);
            else
                Lmin(i)=0;
            end
        end

        Lmin_temp = 0;
        for i=1:N
            if Lmin(i)~=0
                Lmin_temp = Lmin_temp + Lmin(i);
            end
        end
        Lmin_average(k) = Lmin_temp/N;
    end
        R(r)=mean(Lmin_average);
end

figure(2);
stem(R);
