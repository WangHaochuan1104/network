%���������ϵ�� ͼ7

set(0,'defaultfigurecolor','w');%������ͼ��ɫ����
L = 30;%��������
N = 80;%�����нڵ�����
v = 2;%ƽ���ƶ��ٶ�
%r = 2;%ͨ�Ű뾶
t_set = 10;%����ʱ��

position = zeros(N,2);
X = position(:,1);
Y = position(:,2);

for i = 1:N
    X(i) = L.*rand;
    Y(i) = L.*rand;
end

%�ٶ������ֽ�
vx = zeros(N,1);
vy = zeros(N,1);
vy_flag = 1;%y���ٶȷ���

mento_carlo = 100;
C_average = zeros(mento_carlo,1);
R = zeros(7,1);

for r = 1:4
    for k = 1:mento_carlo
        
        for t=1:t_set
            %�ڵ��ƶ�
            for i= 1:N
                vx(i) = -v + 2.*v.*rand;
                vy(i) = -v + 2.*v.*rand;
                if vy(i)>=0
                    vy_flag = 1;
                else
                    vy_flag = -1;
                end
                vy(i) = vy_flag.*sqrt(v.^2-vx(i).^2);
                %���ƶ����ᳬ�����淶Χ����ڵ��ƶ�
                if((X(i)+vx(i))<=L)&&((X(i)+vx(i))>=0)
                    X(i)= X(i)+vx(i);
                end
                if((Y(i)+vy(i))<=L)&&((Y(i)+vy(i))>=0)
                    Y(i)= Y(i)+vy(i);
                end
            end
        end
        
%         figure(1);
%         scatter(X,Y,'filled','r');
%         title('t=10ʱ������Ľڵ�λ�ú�����');
%         for i= 1:N
%             for j = 1:N
%                 if (i~=j)&&(r >= sqrt((X(i)-X(j)).^2 + (Y(i)-Y(j)).^2))
%                     line([X(i) X(j)],[Y(i) Y(j)]);
%                 end
%             end
%         end
%         box on;
              
        %���������ڽӾ���
        M = zeros(N);
        D = zeros(N);
        for i = 1:N
            for j=1:N
                if (i~=j)
                    D(i,j)=sqrt((X(i)-X(j)).^2 + (Y(i)-Y(j)).^2);
                    if(r>=D(i,j))
                        M(i,j)=D(i,j);
                    else
                        M(i,j)=inf;
                    end
                end
            end
        end

        %
        k_num = zeros(1,N);%k���ڵ������ܴ��ڱ���k(k-1)/2
        E_num = zeros(1,N);
        C = zeros(1,N);
        node = zeros(N);
        for i=1:N
            for j=1:N
                if (i~=j)&&(M(i,j)~=inf)
                    k_num(i)=k_num(i)+1;
                    node(i,j)=1;
                end
            end            
        end
        
        for i=1:N
            temp = find(node(i,:));
            for g=1:length(temp)
                for h=1:length(temp)
                    if (g~=h)&&( node(temp(g),temp(h))==1 )
                        E_num(i)=E_num(i)+1;
                    end
                end
            end
            
            if (k_num(i)<=1)
                C(i)=0;
            else
                C(i) = E_num(i)./ ( k_num(i).* (k_num(i)-1) );
            end
        end
        %
        C_average(k) = mean(C);
        
    end
        R(r)=mean(C_average);
end
%%
figure(1);
scatter(X,Y,'filled','r');
title('t=10ʱ������Ľڵ�λ�ú�����');
for i= 1:N
    for j = 1:N
        if (i~=j)&&(r >= sqrt((X(i)-X(j)).^2 + (Y(i)-Y(j)).^2))
            line([X(i) X(j)],[Y(i) Y(j)]);
        end
    end
end
box on;
%%

figure(2);
stem(R);






