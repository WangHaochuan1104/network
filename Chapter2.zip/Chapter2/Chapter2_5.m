%ͼ9

set(0,'defaultfigurecolor','w');%������ͼ��ɫ����
L = 30;%��������
N = 80;%�����нڵ�����
v = 2;%ƽ���ƶ��ٶ�
r = 5;%ͨ�Ű뾶
t_set = 20;%����ʱ��

position = zeros(N,2);
X = position(:,1);
Y = position(:,2);

for i = 1:N
    X(i) = L.*rand;
    Y(i) = L.*rand;
end

%�ٶ������ֽ�
vx = zeros(N,1);
vy = zeros(N,1);
vy_flag = 1;%y���ٶȷ���

mento_carlo = 100;
p_k_average = zeros(mento_carlo,N);
p_k_average2 = zeros(mento_carlo,N);
R = zeros(1,N);
R2 = zeros(1,N);
for k = 1:mento_carlo
    
    for t=1:t_set
        %�ڵ��ƶ�
        for i= 1:N
            vx(i) = -v + 2.*v.*rand;
            vy(i) = -v + 2.*v.*rand;
            if vy(i)>=0
                vy_flag = 1;
            else
                vy_flag = -1;
            end
            vy(i) = vy_flag.*sqrt(v.^2-vx(i).^2);
            %���ƶ����ᳬ�����淶Χ����ڵ��ƶ�
            if((X(i)+vx(i))<=L)&&((X(i)+vx(i))>=0)
                X(i)= X(i)+vx(i);
            end
            if((Y(i)+vy(i))<=L)&&((Y(i)+vy(i))>=0)
                Y(i)= Y(i)+vy(i);
            end
        end
    
        if(t==1)
            %���������ڽӾ���
            M = zeros(N);
            D = zeros(N);
            for i = 1:N
                for j=1:N
                    if (i~=j)
                        D(i,j)=sqrt((X(i)-X(j)).^2 + (Y(i)-Y(j)).^2);
                        if(r>=D(i,j))
                            M(i,j)=D(i,j);
                        else
                            M(i,j)=inf;
                        end
                    end
                end
            end
        end
        
        if(t==t_set)
            %���������ڽӾ���
            M2 = zeros(N);
            D2 = zeros(N);
            for i = 1:N
                for j=1:N
                    if (i~=j)
                        D2(i,j)=sqrt((X(i)-X(j)).^2 + (Y(i)-Y(j)).^2);
                        if(r>=D2(i,j))
                            M2(i,j)=D2(i,j);
                        else
                            M2(i,j)=inf;
                        end
                    end
                end
            end
        end
    end
    
    
    
    %for M1
    
    k_num = zeros(1,N);
    p_k = zeros(1,N);
    for i=1:N
        for j=1:N
            if (i~=j)&&(M(i,j)~=inf)
                k_num(i)=k_num(i)+1;
            end
        end
    end
    
    for i = 1:N
        temp2 = 0;
        for j = 1:N
            if k_num(j)==i
                temp2 = temp2+1;
            end
        end
        p_k(i)=temp2./N;
    end
    %
    p_k_average(k,:) = p_k;
    
    %for M2
    k_num2 = zeros(1,N);
    p_k2 = zeros(1,N);
    for i=1:N
        for j=1:N
            if (i~=j)&&(M2(i,j)~=inf)
                k_num2(i)=k_num2(i)+1;
            end
        end
    end
    
    for i = 1:N
        temp22 = 0;
        for j = 1:N
            if k_num2(j)==i
                temp22 = temp22+1;
            end
        end
        p_k2(i)=temp22./N;
    end
    %
    p_k_average2(k,:) = p_k2;
  
end
R = mean(p_k_average);
R2 = mean(p_k_average2);
figure(1);
plot(R,'-o','color','b');
hold on;
plot(R2,'-pentagram','color','k');
legend('Initial Network','Evolution Network');
box on;
grid minor;

