%������ڵ�

function between = betweenness(A)
    N = size(A,1);
    between = zeros(N,1);
%     for i=1:N
%         for j=1:N
%             [dist path] = graphshortestpath(A,i,j);
%             for k=1:N
%                 if (k~=j)&&(k~=i)
%                     between(k)= between(k) + length( find(path==k) );
%                 end
%             end
%         end
%     end
    for i = 1:N
        [~, path] = graphshortestpath(A,i);
        path2 = cell2mat(path);
        for k = 1:N
            if (k~=i)&&( (length(find(path2==k)))>0 )
                between(k) = between(k) + length(find(path2==k)) - 1; 
            end
        end
    end
        
        
        
end